# Calculator Project

### Having simple operations like Addition, Substraction, multiplication and division.

Used Flask for creating the web application.
